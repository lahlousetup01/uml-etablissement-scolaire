import sys
sys.path.insert(0, "/home/claude/uml_exam")
from uml_helpers import *

fig, ax = new_fig(14, 17)
CX = 55
RX = 108

def action(cx, cy, w, h, text, fs=8.5, fc=CARD):
    box(ax, cx - w/2, cy - h/2, w, h, text, fc=fc, fs=fs)

def dec(cx, cy, w, h, text, fs=8.2):
    diamond(ax, cx, cy, w, h, text, fs=fs)

def flow(x1, y1, x2, y2, label=None, color=NAVY_LIGHT, rad=0.0, lx=None, ly=None, fs=7.6):
    arrow(ax, x1, y1, x2, y2, color=color, connstyle=f"arc3,rad={rad}")
    if label:
        ax.text(lx if lx is not None else (x1+x2)/2 + 2, ly if ly is not None else (y1+y2)/2,
                 label, fontsize=fs, color=DARK, style="italic")

rounded_start_end(ax, CX, 4, 1.6, NAVY)
action(CX, 12, 46, 9, "L'enseignant déclare une absence\nou signale un retard en début de cours")
flow(CX, 5.6, CX, 7.5)

dec(CX, 24, 32, 12, "L'élève entre\nen classe ?")
flow(CX, 16.5, CX, 18)

action(RX, 24, 34, 8, "L'enseignant modifie\nl'enregistrement")
flow(CX+16, 24, RX-17, 24, "oui", ly=21)
rounded_start_end(ax, RX, 34, 1.7, NAVY)
flow(RX, 28, RX, 32.3)

dec(CX, 36, 32, 12, "Retard dépasse le\ndélai autorisé ?")
flow(CX, 30, CX, 30.2, "non", lx=CX+18, ly=27)

action(CX, 48, 42, 8, "Basculer automatiquement\nl'enregistrement en « absence »")
flow(CX, 42, CX, 43.5, "oui", lx=CX+3)

action(CX, 59, 46, 8, "Le personnel de vie scolaire\nvérifie l'absence")
flow(CX, 52, CX, 54.5)

dec(CX, 71, 32, 12, "Justificatif\nfourni ?")
flow(CX, 63, CX, 65)

dec(RX, 71, 32, 12, "Justificatif\naccepté ?")
flow(CX+16, 71, RX-16, 71, "oui", ly=68)

action(CX, 84, 40, 9, "L'absence reste\n« non justifiée »")
flow(CX, 77, CX, 79, "non", lx=CX+3)
flow(RX, 77, CX+8, 82, "non", lx=RX+2, ly=79, rad=0.2)

action(RX, 84, 36, 8, "L'absence devient\n« justifiée »")
flow(RX, 77, RX, 79.5, "oui", lx=RX+3)
rounded_start_end(ax, RX, 96, 1.7, NAVY)
flow(RX, 88, RX, 94)

action(CX, 96, 44, 8, "Notifier automatiquement\nles parents (non justifiée)")
flow(CX, 88.5, CX, 91.5)

action(CX, 107, 44, 8, "Mettre à jour l'historique\ndes absences de l'élève")
flow(CX, 100.5, CX, 102.5)

dec(CX, 119, 36, 12, "Comportement répétitif\ndétecté (fréquence) ?")
flow(CX, 111.5, CX, 113)

action(RX, 119, 36, 9, "Envoyer une alerte automatique\naux parents / à la direction")
flow(CX+18, 119, RX-18, 119, "oui", ly=116)
rounded_start_end(ax, RX, 130, 1.7, NAVY)
flow(RX, 123.5, RX, 128)

rounded_start_end(ax, CX, 130, 1.9, NAVY)
ax.add_patch(plt.Circle((CX, 130), 1.1, facecolor="white", edgecolor=NAVY, linewidth=1.6, zorder=4))
flow(CX, 125, CX, 128, "non", lx=CX+3)

ax.set_title("Diagramme d'activité 2 — Gestion d'une absence",
             fontsize=13, fontweight="bold", color=NAVY, pad=12)

save(fig, "/home/claude/uml_exam/diagrams/05_activite_absence.png")
