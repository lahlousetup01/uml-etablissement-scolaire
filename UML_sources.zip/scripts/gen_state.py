import sys
sys.path.insert(0, "/home/claude/uml_exam")
from uml_helpers import *

fig, ax = new_fig(17, 11)

def state(cx, cy, w, h, text, fs=9, fc=CARD):
    box(ax, cx-w/2, cy-h/2, w, h, text, fc=fc, fs=fs, radius=0.6, bold=True)
    return (cx, cy, w, h)

def trans(c1, c2, label, rad=0.0, fs=7.6, lx=None, ly=None, self_loop=False):
    x1, y1, w1, h1 = c1
    x2, y2, w2, h2 = c2
    if self_loop:
        arrow(ax, x1 + w1/2 - 2, y1 - h1/2, x1 + w1/2 + 8, y1 - h1/2 - 6, color=NAVY_LIGHT,
              connstyle="arc3,rad=1.4")
        ax.text(x1 + w1/2 + 3, y1 - h1/2 - 9, label, fontsize=fs, color=DARK, ha="center")
        return
    arrow(ax, x1, y1, x2, y2, color=NAVY_LIGHT, connstyle=f"arc3,rad={rad}")
    ax.text(lx if lx is not None else (x1+x2)/2, ly if ly is not None else (y1+y2)/2 - 1.6,
             label, fontsize=fs, color=DARK, ha="center",
             bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none"))

# Initial
rounded_start_end(ax, 10, 30, 1.7, NAVY)
Incomplet = state(32, 30, 30, 11, "Incomplet")
arrow(ax, 11.7, 30, 16.5, 30, color=NAVY)

EnVerif = state(75, 30, 34, 11, "En vérification")
trans(Incomplet, EnVerif, "dossier complet\nsoumis", lx=54, ly=25)
trans(EnVerif, Incomplet, "document manquant /\nnon conforme", rad=0.35, lx=54, ly=38)

Refuse = state(75, 60, 32, 11, "Refusé", fc="#FDEBEA")
trans(EnVerif, Refuse, "entretien non\nsatisfaisant", lx=90, ly=44)
rounded_start_end(ax, 75, 78, 1.9, RED)
ax.add_patch(plt.Circle((75, 78), 1.1, facecolor="white", edgecolor=RED, linewidth=1.6, zorder=4))
arrow(ax, 75, 65.5, 75, 76, color=RED)

Preinsc = state(118, 30, 32, 11, "Préinscrit")
trans(EnVerif, Preinsc, "documents validés +\nentretien accepté", lx=97, ly=24)

PreinscPaie = state(118, 55, 40, 11, "Préinscrit en attente\nde paiement")
trans(Preinsc, PreinscPaie, "frais générés", lx=132, ly=42)
trans(PreinscPaie, PreinscPaie, "retard de paiement /\npénalité appliquée", self_loop=True)

Inscrit = state(75, 90, 30, 11, "Inscrit", fc="#E8F5E9")
trans(PreinscPaie, Inscrit, "paiement confirmé", rad=0.2, lx=98, ly=74)
rounded_start_end(ax, 75, 105, 1.9, GREEN)
ax.add_patch(plt.Circle((75, 105), 1.1, facecolor="white", edgecolor=GREEN, linewidth=1.6, zorder=4))
arrow(ax, 75, 95.5, 75, 103, color=GREEN)

ax.set_title("Diagramme d'états-transitions (bonus) — Classe DossierInscription",
             fontsize=13.5, fontweight="bold", color=NAVY, pad=12)

save(fig, "/home/claude/uml_exam/diagrams/07_etats_dossier.png")
