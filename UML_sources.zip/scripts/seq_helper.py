import sys
sys.path.insert(0, "/home/claude/uml_exam")
from uml_helpers import *


def draw_sequence(title, participants, messages, out_path, w=15.5, top_gap=14, row_h=6.2, fs=8.7):
    """
    participants: list of names (in order, left to right)
    messages: list of dicts:
      {"from": name, "to": name, "text": str, "type": "sync"/"return"/"self", "note": optional str}
      use "cond": "[condition]" to place an alt/opt bracket label before a group; simplistic linear layout.
    """
    n = len(participants)
    h = top_gap + row_h * len(messages) + 6
    fig, ax = new_fig(w, h / 10)
    W = w * 10
    H = h

    xs = {}
    margin = 12
    spacing = (W - 2 * margin) / (n - 1) if n > 1 else 0
    for i, p in enumerate(participants):
        xs[p] = margin + i * spacing

    # lifelines + headers
    for p in participants:
        box(ax, xs[p] - 12, 2, 24, 8, p, fc=NAVY, tc="white", fs=fs + 0.3, bold=True, radius=0.3)
        ax.plot([xs[p], xs[p]], [10, H - 4], color=GREY, lw=1.1, linestyle=(0, (4, 3)), zorder=0)

    y = top_gap
    for m in messages:
        if m.get("kind") == "note":
            ax.add_patch(FancyBboxPatch((xs[m["at"]] - 20, y - 2.4), 40, 4.6, boxstyle="round,pad=0,rounding_size=0.2",
                                         facecolor="#FFF6E8", edgecolor=GOLD, linewidth=1.1, zorder=2))
            ax.text(xs[m["at"]], y - 0.1, m["text"], ha="center", va="center", fontsize=fs - 0.8,
                    style="italic", color=DARK, zorder=3)
            y += row_h * 0.85
            continue
        if m.get("kind") == "frame":
            ax.text(margin - 10, y, m["text"], fontsize=fs - 0.3, color=RED, fontweight="bold", ha="left")
            y += row_h * 0.7
            continue

        x1, x2 = xs[m["from"]], xs[m["to"]]
        ls = "-" if m.get("type", "sync") != "return" else "--"
        col = NAVY_LIGHT if m.get("type") != "return" else GREY
        if x1 == x2:
            # self message (small loop)
            ax.annotate("", xy=(x1 + 8, y + 1.6), xytext=(x1, y),
                        arrowprops=dict(arrowstyle="-|>", color=col, lw=1.3,
                                        connectionstyle="arc3,rad=-1.1"))
            ax.text(x1 + 9, y + 0.5, m["text"], fontsize=fs - 0.5, color=DARK, va="center")
        else:
            arrow(ax, x1, y, x2, y, color=col, lw=1.3, ls=ls)
            midx = (x1 + x2) / 2
            ax.text(midx, y - 1.0, m["text"], fontsize=fs - 0.4, color=DARK, ha="center", va="bottom")
        y += row_h

    ax.set_title(title, fontsize=12.5, fontweight="bold", color=NAVY, pad=10)
    save(fig, out_path)
