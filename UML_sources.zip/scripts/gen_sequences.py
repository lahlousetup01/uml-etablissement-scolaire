import sys
sys.path.insert(0, "/home/claude/uml_exam")
from seq_helper import draw_sequence

# ============================================================
# Séquence 1 : Dépôt et vérification du dossier d'inscription
# ============================================================
participants1 = ["Parent", "Portail\n(IHM)", "Contrôleur\nInscription", "Base de\nDonnées"]

messages1 = [
    {"from": "Parent", "to": "Portail\n(IHM)", "text": "1: remplirDossier(infos, contacts, médical)"},
    {"from": "Portail\n(IHM)", "to": "Contrôleur\nInscription", "text": "2: soumettreDocument(doc)"},
    {"kind": "frame", "text": "alt  [vérification automatique du format]"},
    {"from": "Contrôleur\nInscription", "to": "Contrôleur\nInscription", "text": "3: vérifierFormat(doc)"},
    {"kind": "note", "at": "Contrôleur\nInscription",
     "text": "[format invalide] → signaler l'erreur, conserver les pièces déjà valides"},
    {"from": "Contrôleur\nInscription", "to": "Portail\n(IHM)", "text": "4: erreurFormat(doc)", "type": "return"},
    {"from": "Portail\n(IHM)", "to": "Parent", "text": "5: demanderNouveauDépôt(doc)"},
    {"kind": "note", "at": "Contrôleur\nInscription", "text": "[format valide]"},
    {"from": "Contrôleur\nInscription", "to": "Base de\nDonnées", "text": "6: enregistrerDocument(doc)"},
    {"from": "Parent", "to": "Portail\n(IHM)", "text": "7: soumettreDossierFinal()"},
    {"from": "Portail\n(IHM)", "to": "Contrôleur\nInscription", "text": "8: vérifierDossierComplet()"},
    {"kind": "frame", "text": "alt  [complétude du dossier]"},
    {"kind": "note", "at": "Contrôleur\nInscription", "text": "[incomplet] → un seul élément manquant suffit à bloquer"},
    {"from": "Contrôleur\nInscription", "to": "Base de\nDonnées", "text": "9: maintenirÉtat(dossier, \"incomplet\")"},
    {"from": "Contrôleur\nInscription", "to": "Portail\n(IHM)", "text": "10: dossierIncomplet(liste manquants)", "type": "return"},
    {"kind": "note", "at": "Contrôleur\nInscription", "text": "[complet]"},
    {"from": "Contrôleur\nInscription", "to": "Base de\nDonnées", "text": "11: changerÉtat(dossier, \"en_vérification\")"},
    {"from": "Contrôleur\nInscription", "to": "Portail\n(IHM)", "text": "12: confirmationSoumission()", "type": "return"},
    {"from": "Portail\n(IHM)", "to": "Parent", "text": "13: afficherConfirmation()"},
]

draw_sequence(
    "Diagramme de séquence 1 — Dépôt et vérification du dossier d'inscription",
    participants1, messages1, "/home/claude/uml_exam/diagrams/02_sequence_inscription.png",
    row_h=6.0
)

# ============================================================
# Séquence 2 : Paiement en ligne des frais d'inscription
# ============================================================
participants2 = ["Parent", "Portail\n(IHM)", "Module\nFinancier", "Service\nBancaire", "Base de\nDonnées"]

messages2 = [
    {"from": "Parent", "to": "Portail\n(IHM)", "text": "1: choisirPaiementImmédiat()"},
    {"from": "Portail\n(IHM)", "to": "Module\nFinancier", "text": "2: initierPaiement(montant)"},
    {"from": "Module\nFinancier", "to": "Service\nBancaire", "text": "3: demanderAutorisation(montant, moyen)"},
    {"kind": "frame", "text": "alt  [réponse du service bancaire]"},
    {"kind": "note", "at": "Service\nBancaire", "text": "[acceptation]"},
    {"from": "Service\nBancaire", "to": "Module\nFinancier", "text": "4: paiementAccepté()", "type": "return"},
    {"from": "Module\nFinancier", "to": "Base de\nDonnées", "text": "5: mettreAJourFacture(\"payée\")"},
    {"from": "Module\nFinancier", "to": "Base de\nDonnées", "text": "6: changerÉtatÉlève(\"inscrit\")"},
    {"from": "Module\nFinancier", "to": "Portail\n(IHM)", "text": "7: confirmerPaiement()", "type": "return"},
    {"kind": "note", "at": "Service\nBancaire", "text": "[erreur temporaire]"},
    {"from": "Service\nBancaire", "to": "Module\nFinancier", "text": "8: erreurTemporaire()", "type": "return"},
    {"from": "Module\nFinancier", "to": "Portail\n(IHM)", "text": "9: proposerNouvelEssai()", "type": "return"},
    {"kind": "note", "at": "Service\nBancaire", "text": "[refus définitif]"},
    {"from": "Service\nBancaire", "to": "Module\nFinancier", "text": "10: refus()", "type": "return"},
    {"from": "Module\nFinancier", "to": "Portail\n(IHM)", "text": "11: proposerAutreModePaiement()", "type": "return"},
    {"from": "Portail\n(IHM)", "to": "Parent", "text": "12: afficherRésultat()"},
]

draw_sequence(
    "Diagramme de séquence 2 — Paiement en ligne des frais d'inscription",
    participants2, messages2, "/home/claude/uml_exam/diagrams/03_sequence_paiement.png",
    row_h=6.0
)
