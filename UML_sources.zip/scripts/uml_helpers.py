"""
Helpers communs pour dessiner les diagrammes UML (matplotlib).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Ellipse, Rectangle
import matplotlib.font_manager as fm

NAVY = "#1E2761"
NAVY_LIGHT = "#4B63C4"
GOLD = "#E8A33D"
CARD = "#F4F6FB"
DARK = "#1B1B1B"
GREY = "#6B7280"
WHITE = "#FFFFFF"
GREEN = "#2E7D32"
RED = "#B3261E"

plt.rcParams["font.family"] = "DejaVu Sans"


def new_fig(w, h):
    fig, ax = plt.subplots(figsize=(w, h), dpi=200)
    ax.set_xlim(0, w * 10)
    ax.set_ylim(0, h * 10)
    ax.axis("off")
    ax.invert_yaxis()
    return fig, ax


def save(fig, path):
    fig.savefig(path, bbox_inches="tight", facecolor="white", pad_inches=0.25)
    plt.close(fig)
    print("saved", path)


def box(ax, x, y, w, h, text, fc=CARD, ec=NAVY, tc=DARK, fs=10, bold=False, radius=0.15, title=None, title_fc=NAVY):
    b = FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={radius}",
                        linewidth=1.4, edgecolor=ec, facecolor=fc, zorder=2)
    ax.add_patch(b)
    if title:
        th = min(0.7, h * 0.28)
        tb = FancyBboxPatch((x, y), w, th, boxstyle=f"round,pad=0,rounding_size={radius}",
                             linewidth=0, facecolor=title_fc, zorder=3)
        ax.add_patch(tb)
        ax.add_patch(Rectangle((x, y + th - radius), w, radius, facecolor=title_fc, edgecolor="none", zorder=3))
        ax.text(x + w / 2, y + th / 2, title, ha="center", va="center", fontsize=fs + 1,
                fontweight="bold", color="white", zorder=4)
        ax.text(x + w / 2, y + th + (h - th) / 2, text, ha="center", va="center", fontsize=fs,
                color=tc, zorder=4, wrap=True)
    else:
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs,
                fontweight="bold" if bold else "normal", color=tc, zorder=4, wrap=True)
    return b


def ellipse(ax, cx, cy, w, h, text, fc=CARD, ec=NAVY, fs=9.5):
    e = Ellipse((cx, cy), w, h, facecolor=fc, edgecolor=ec, linewidth=1.4, zorder=2)
    ax.add_patch(e)
    ax.text(cx, cy, text, ha="center", va="center", fontsize=fs, color=DARK, zorder=3, wrap=True)
    return e


def arrow(ax, x1, y1, x2, y2, style="-|>", color=NAVY, lw=1.3, ls="-", connstyle="arc3,rad=0", zorder=1):
    a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=14,
                         color=color, linewidth=lw, linestyle=ls, connectionstyle=connstyle, zorder=zorder)
    ax.add_patch(a)
    return a


def actor(ax, cx, cy, label, scale=1.0, color=NAVY):
    r = 0.35 * scale
    ax.add_patch(plt.Circle((cx, cy), r, facecolor=color, edgecolor=color, zorder=3))
    ax.plot([cx, cx], [cy + r, cy + r + 1.1 * scale], color=color, lw=2, zorder=3)
    ax.plot([cx - 0.65 * scale, cx + 0.65 * scale], [cy + r + 0.35 * scale, cy + r + 0.35 * scale], color=color, lw=2, zorder=3)
    ax.plot([cx, cx - 0.55 * scale], [cy + r + 1.1 * scale, cy + r + 1.85 * scale], color=color, lw=2, zorder=3)
    ax.plot([cx, cx + 0.55 * scale], [cy + r + 1.1 * scale, cy + r + 1.85 * scale], color=color, lw=2, zorder=3)
    ax.text(cx, cy + r + 2.25 * scale, label, ha="center", va="top", fontsize=9.5, fontweight="bold", color=color)


def diamond(ax, cx, cy, w, h, text, fc="#FFF6E8", ec=GOLD, fs=8.5):
    pts = [(cx, cy - h / 2), (cx + w / 2, cy), (cx, cy + h / 2), (cx - w / 2, cy)]
    poly = plt.Polygon(pts, closed=True, facecolor=fc, edgecolor=ec, linewidth=1.4, zorder=2)
    ax.add_patch(poly)
    ax.text(cx, cy, text, ha="center", va="center", fontsize=fs, color=DARK, zorder=3, wrap=True)


def rounded_start_end(ax, cx, cy, r, fc, label=None):
    ax.add_patch(plt.Circle((cx, cy), r, facecolor=fc, edgecolor=NAVY, linewidth=1.6, zorder=3))
    if label:
        ax.text(cx, cy + r + 0.3, label, ha="center", va="bottom", fontsize=8.5, color=DARK)
