import sys
sys.path.insert(0, "/home/claude/uml_exam")
from uml_helpers import *

fig, ax = new_fig(19, 15.5)

def uml_class(cx, cy, w, name, attrs, fs=7.6):
    h_title = 6
    h_attr = 3.6 * len(attrs) + 2
    h = h_title + h_attr
    x, y = cx - w/2, cy - h/2
    box(ax, x, y, w, h_title, name, fc=NAVY, tc="white", fs=fs+0.6, bold=True, radius=0.25)
    box(ax, x, y+h_title, w, h_attr, "", fc=CARD, fs=fs, radius=0.0)
    ax.plot([x, x+w], [y+h_title, y+h_title], color=NAVY, lw=1.2, zorder=5)
    ty = y + h_title + 2
    for a in attrs:
        ax.text(x + 2.5, ty, "- " + a, fontsize=fs, color=DARK, ha="left", va="top")
        ty += 3.6
    return (cx, cy, w, h)

def rel(c1, c2, m1="", m2="", label="", rad=0.0, fs=6.6, lx=None, ly=None):
    x1, y1, w1, h1 = c1
    x2, y2, w2, h2 = c2
    arrow(ax, x1, y1, x2, y2, style="-", color=GREY, lw=1.0, connstyle=f"arc3,rad={rad}")
    dx, dy = x2 - x1, y2 - y1
    dist = max((dx**2+dy**2)**0.5, 1e-6)
    ux, uy = dx/dist, dy/dist
    ax.text(x1 + ux*(w1/2+2), y1 + uy*(h1/2+2), m1, fontsize=fs, color=GREY)
    ax.text(x2 - ux*(w2/2+3), y2 - uy*(h2/2+3), m2, fontsize=fs, color=GREY)
    if label:
        ax.text(lx if lx is not None else (x1+x2)/2, ly if ly is not None else (y1+y2)/2 - 1.5,
                 label, fontsize=fs+0.4, color=NAVY, style="italic", ha="center",
                 bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none"))

# ---- Positions (grille) ----
Utilisateur = uml_class(24, 16, 40, "Utilisateur", ["id", "nom, prenom", "email", "motDePasse", "roles : List<Role>"])
Role        = uml_class(74, 12, 34, "Role", ["id", "nomRole"])
Dossier     = uml_class(122, 16, 40, "DossierInscription", ["id", "etat", "dateCreation"])
Document    = uml_class(168, 16, 34, "Document", ["id", "type", "format", "statut"])

Eleve       = uml_class(24, 46, 38, "Eleve", ["id", "nom, prenom", "dateNaissance", "niveau", "etatInscription"])
Classe      = uml_class(74, 46, 32, "Classe", ["id", "niveau", "capacite"])
Cours       = uml_class(122, 46, 34, "Cours", ["id", "matiere", "horaire"])
Note        = uml_class(168, 46, 30, "Note", ["id", "valeur", "verrouillee"])

Absence     = uml_class(24, 78, 34, "Absence", ["id", "date", "type", "statut"])
Facture     = uml_class(74, 78, 32, "Facture", ["id", "montant", "etat", "echeance"])
Paiement    = uml_class(122, 78, 34, "Paiement", ["id", "montant", "mode", "statut"])
Notification= uml_class(168, 78, 36, "Notification", ["id", "type", "canal", "luConfirme"])

Equipement  = uml_class(50, 108, 34, "Equipement", ["id", "type", "etat", "dateAchat"])
Incident    = uml_class(100, 108, 34, "Incident", ["id", "type", "etat"])
Conge       = uml_class(150, 108, 34, "Conge", ["id", "dateDebut/Fin", "statut"])

# ---- Relations ----
rel(Utilisateur, Role, "1", "0..*", "possède", lx=49, ly=13)
rel(Eleve, Dossier, "1", "1", "possède", rad=0.15, lx=70, ly=32)
rel(Dossier, Document, "1", "1..*", "contient", lx=145, ly=16)
rel(Eleve, Classe, "0..1", "1", "affecté à", lx=49, ly=46)
rel(Classe, Cours, "1", "0..*", "programme", lx=98, ly=46)
rel(Cours, Note, "1", "0..*", "génère", lx=145, ly=46)
rel(Eleve, Note, "1", "0..*", "obtient", rad=0.28, lx=95, ly=62)
rel(Eleve, Absence, "1", "0..*", "concerne", lx=24, ly=62)
rel(Eleve, Facture, "1", "0..*", "concerne", rad=-0.22, lx=48, ly=64)
rel(Facture, Paiement, "1", "0..*", "réglée par", lx=98, ly=78)
rel(Equipement, Incident, "1", "0..*", "lié à", lx=75, ly=108)
rel(Utilisateur, Cours, "1", "0..*", "enseigne (si rôle Enseignant)", rad=-0.35, lx=24, ly=95, fs=6.2)
rel(Utilisateur, Notification, "1", "0..*", "destinataire", rad=0.3, lx=168, ly=48)
rel(Utilisateur, Incident, "1", "0..*", "signale", rad=-0.2, lx=60, ly=95, fs=6.2)
rel(Utilisateur, Conge, "1", "0..*", "demande", rad=-0.3, lx=95, ly=125, fs=6.2)

ax.set_title("Diagramme de classes (simplifié) — Architecture générale du système",
             fontsize=13.5, fontweight="bold", color=NAVY, pad=12)

save(fig, "/home/claude/uml_exam/diagrams/06_classes.png")
