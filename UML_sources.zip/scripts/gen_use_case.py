import sys
sys.path.insert(0, "/home/claude/uml_exam")
from uml_helpers import *

fig, ax = new_fig(15.5, 10.5)
W, H = 155, 105

# ---- Système boundary ----
sysbox = FancyBboxPatch((30, 5), 108, 92, boxstyle="round,pad=0,rounding_size=1",
                         linewidth=1.8, edgecolor=NAVY, facecolor="white", zorder=1)
ax.add_patch(sysbox)
ax.text(84, 8, "Système de Gestion de l'Établissement", ha="center", va="top",
        fontsize=12.5, fontweight="bold", color=NAVY)

# ---- Actors (left) ----
actor(ax, 10, 25, "Parent")
actor(ax, 10, 55, "Enseignant")
actor(ax, 10, 85, "Personnel de\nvie scolaire")

# ---- Actors (right) ----
actor(ax, 145, 15, "Personnel\nadministratif")
actor(ax, 145, 40, "Personnel\nfinancier")
actor(ax, 145, 65, "Direction /\nResp. pédagogique")
actor(ax, 145, 90, "Administrateur")

# Service bancaire (external actor, bottom)
actor(ax, 84, 100, "Service bancaire\n(système externe)")

# ---- Use cases ----
uc = {}
def U(key, cx, cy, w, h, text, fs=8.7):
    ellipse(ax, cx, cy, w, h, text, fs=fs)
    uc[key] = (cx, cy, w, h)

U("auth",      45, 15, 22, 8.5, "S'authentifier")
U("dossier",   65, 26, 26, 9,   "Créer / suivre le\ndossier d'inscription")
U("deposer",   65, 40, 24, 9,   "Déposer des\ndocuments")
U("verif_doc", 92, 40, 24, 9,   "Vérifier / valider\nles documents")
U("entretien", 92, 26, 24, 9,   "Planifier / évaluer\nl'entretien")
U("paiement",  65, 55, 24, 9,   "Effectuer un\npaiement")
U("facture",   92, 55, 22, 9,   "Gérer les\nfactures")
U("notes",     45, 68, 22, 9,   "Saisir / modifier\nles notes")
U("absence",   65, 80, 22, 9,   "Déclarer une\nabsence")
U("justif",    92, 80, 22, 9,   "Justifier une\nabsence")
U("emploi",    118, 26, 22, 9,  "Gérer l'emploi\ndu temps")
U("incident",  118, 55, 22, 9,  "Signaler un\nincident matériel")
U("conge",     118, 80, 22, 9,  "Gérer les\ncongés")
U("bulletin",  45, 55, 20, 9,   "Générer le\nbulletin")
U("notif",     118, 40, 20, 9,  "Gérer les\nnotifications")

# ---- Actor -> use case links ----
def link(p1, key, **kw):
    cx, cy, w, h = uc[key]
    ax.plot([p1[0], cx], [p1[1], cy], color=GREY, lw=1.1, zorder=1, **kw)

link((10, 25), "dossier")
link((10, 25), "deposer")
link((10, 25), "paiement")
link((10, 25), "bulletin")
link((10, 55), "notes")
link((10, 55), "absence")
link((10, 85), "justif")
link((10, 85), "absence")

link((145, 15), "verif_doc")
link((145, 15), "entretien")
link((145, 40), "paiement")
link((145, 40), "facture")
link((145, 65), "emploi")
link((145, 65), "conge")
link((145, 90), "notif")
link((84, 100), "paiement")

for k in ["auth", "dossier", "deposer", "notes", "paiement", "incident"]:
    link((10, 25) if k in ("auth",) else (10, 25), k) if False else None

# S'authentifier lié par include depuis plusieurs UC (représentation simplifiée)
ax.annotate("", xy=(56, 18), xytext=(56, 24), arrowprops=dict(arrowstyle="->", color=GREY, lw=1, linestyle="dashed"))
ax.text(58, 20, "«include»", fontsize=7, color=GREY, style="italic")

ax.annotate("", xy=(90, 30), xytext=(78, 27), arrowprops=dict(arrowstyle="->", color=GREY, lw=1, linestyle="dashed"))
ax.text(80, 24.5, "«extend»", fontsize=7, color=GREY, style="italic")

ax.annotate("", xy=(90, 42), xytext=(78, 41), arrowprops=dict(arrowstyle="->", color=GREY, lw=1, linestyle="dashed"))
ax.text(79, 45, "«include»", fontsize=7, color=GREY, style="italic")

ax.annotate("", xy=(90, 81), xytext=(78, 80), arrowprops=dict(arrowstyle="->", color=GREY, lw=1, linestyle="dashed"))
ax.text(79, 84, "«extend»", fontsize=7, color=GREY, style="italic")

ax.set_title("Diagramme des cas d'utilisation — Gestion d'un établissement d'enseignement",
             fontsize=13, fontweight="bold", color=NAVY, pad=14)

save(fig, "/home/claude/uml_exam/diagrams/01_use_case.png")
