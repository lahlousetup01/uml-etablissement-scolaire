import sys
sys.path.insert(0, "/home/claude/uml_exam")
from uml_helpers import *

fig, ax = new_fig(14, 21)
W, H = 140, 210

CX = 55   # colonne centrale (flux principal)
RX = 108  # colonne droite (branches alternatives / notifications)

def action(cx, cy, w, h, text, fs=8.5, fc=CARD):
    box(ax, cx - w/2, cy - h/2, w, h, text, fc=fc, fs=fs)

def dec(cx, cy, w, h, text, fs=8.2):
    diamond(ax, cx, cy, w, h, text, fs=fs)

def flow(x1, y1, x2, y2, label=None, color=NAVY_LIGHT, rad=0.0, lx=None, ly=None, fs=7.6, lcolor=DARK):
    arrow(ax, x1, y1, x2, y2, color=color, connstyle=f"arc3,rad={rad}")
    if label:
        ax.text(lx if lx is not None else (x1+x2)/2 + 2, ly if ly is not None else (y1+y2)/2,
                 label, fontsize=fs, color=lcolor, style="italic")

# Start
rounded_start_end(ax, CX, 4, 1.6, NAVY)

action(CX, 12, 46, 8, "Remplir les informations et\ndéposer les documents requis")
flow(CX, 5.6, CX, 8, )

dec(CX, 24, 34, 12, "Format du\ndocument valide ?")
flow(CX, 16, CX, 18)

action(RX, 24, 36, 9, "Signaler l'erreur, conserver\nles pièces déjà valides")
flow(CX+17, 24, RX-18, 24, "non", ly=21)
flow(RX, 19.5, CX, 12, rad=-0.25)

action(CX, 36, 40, 8, "Enregistrer le document validé")
flow(CX, 30, CX, 32, "oui", lx=CX+3)

action(CX, 46, 44, 8, "Soumettre le dossier pour\nvérification finale")
flow(CX, 40, CX, 42)

dec(CX, 58, 32, 12, "Dossier\ncomplet ?")
flow(CX, 50, CX, 52)

action(RX, 58, 34, 9, "État = « Incomplet »\nnotifier le parent")
flow(CX+16, 58, RX-17, 58, "non", ly=55)
flow(RX, 53, CX, 13, rad=0.35)

action(CX, 70, 40, 8, "État = « En vérification »")
flow(CX, 64, CX, 66, "oui", lx=CX+3)

action(CX, 80, 46, 9, "Le personnel administratif\nvérifie chaque document")
flow(CX, 74, CX, 75.5)

dec(CX, 92, 34, 12, "Documents\nconformes ?")
flow(CX, 84.5, CX, 86)

action(RX, 92, 34, 9, "Demander un document\nsupplémentaire au parent")
flow(CX+17, 92, RX-17, 92, "non", ly=89)
flow(RX, 87.5, CX, 81, rad=-0.35)

action(CX, 104, 42, 8, "Proposer un rendez-vous\nd'entretien (si requis)")
flow(CX, 98, CX, 100, "oui", lx=CX+3)

dec(CX, 116, 34, 12, "Entretien\nsatisfaisant ?")
flow(CX, 108, CX, 110)

action(RX, 116, 34, 9, "Refuser l'inscription\nnotifier le parent (motif)")
flow(CX+17, 116, RX-17, 116, "non", ly=113)
rounded_start_end(ax, RX, 128, 1.9, RED)
ax.text(RX, 128, "Refusé", ha="center", va="center", fontsize=7.5, color="white", fontweight="bold")
flow(RX, 120.5, RX, 126)

action(CX, 128, 40, 8, "État = « Préinscrit »")
flow(CX, 122, CX, 124, "oui", lx=CX+3)

action(CX, 138, 46, 9, "Générer frais d'inscription,\nfournitures et frais annexes")
flow(CX, 132, CX, 133.5)

action(CX, 149, 48, 9, "Le parent choisit le mode de\npaiement (immédiat / différé / échelonné)")
flow(CX, 142.5, CX, 144.5)

dec(CX, 161, 34, 12, "Paiement\nconfirmé ?")
flow(CX, 153.5, CX, 155)

action(RX, 161, 36, 9, "« Préinscrit en attente\nde paiement » + pénalités")
flow(CX+17, 161, RX-18, 161, "non", ly=158)
flow(RX, 156.5, CX, 150, rad=-0.3)

action(CX, 173, 40, 8, "État = « Inscrit »")
flow(CX, 167, CX, 169, "oui", lx=CX+3)

action(CX, 184, 46, 9, "Attribuer une classe (âge, niveau,\nplaces disponibles, résultats)")
flow(CX, 177, CX, 179.5)

rounded_start_end(ax, CX, 194, 1.9, NAVY)
ax.add_patch(plt.Circle((CX, 194), 1.1, facecolor="white", edgecolor=NAVY, linewidth=1.6, zorder=4))
flow(CX, 188.5, CX, 192)

ax.set_title("Diagramme d'activité 1 — Processus complet d'inscription d'un élève",
             fontsize=13, fontweight="bold", color=NAVY, pad=12)

save(fig, "/home/claude/uml_exam/diagrams/04_activite_inscription.png")
