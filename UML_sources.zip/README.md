# Sources des diagrammes UML — Gestion d'un établissement d'enseignement

## Contenu de cette archive

- `diagrams/` : les 7 diagrammes UML au format PNG (haute résolution), tels qu'insérés
  dans le document PDF rendu.
- `scripts/` : les scripts Python (matplotlib) ayant généré chaque diagramme. Ce sont
  les véritables fichiers "source" : ils sont modifiables et permettent de régénérer
  ou d'ajuster n'importe quel diagramme (positions, textes, couleurs).

## Diagrammes fournis

1. `01_use_case.png` — Diagramme des cas d'utilisation
2. `02_sequence_inscription.png` — Séquence : dépôt et vérification du dossier
3. `03_sequence_paiement.png` — Séquence : paiement en ligne
4. `04_activite_inscription.png` — Activité : processus complet d'inscription
5. `05_activite_absence.png` — Activité : gestion d'une absence
6. `06_classes.png` — Diagramme de classes simplifié
7. `07_etats_dossier.png` — Diagramme d'états-transitions (bonus) : DossierInscription

## Remarque importante concernant StarUML

L'énoncé recommande StarUML pour la réalisation des diagrammes. Ces diagrammes ont
été produits par génération programmatique (Python/matplotlib) plutôt qu'avec StarUML,
il n'existe donc pas de fichier `.mdj` natif dans cette archive.

Si votre professeur exige strictement un fichier StarUML :
- Utilisez les images de `diagrams/` comme plan de référence (structure, textes,
  cardinalités, états) et recréez rapidement chaque diagramme dans StarUML en vous
  appuyant dessus — StarUML propose des palettes dédiées à chaque type de diagramme
  UML utilisé ici (cas d'utilisation, séquence, activité, classes, états).
- Sinon, comme l'énoncé indique que StarUML est seulement "recommandé", ces sources
  Python modifiables peuvent être présentées comme fichiers sources alternatifs.

## Régénérer les diagrammes

```bash
pip install matplotlib --break-system-packages
python3 scripts/gen_use_case.py
python3 scripts/gen_sequences.py
python3 scripts/gen_activity1.py
python3 scripts/gen_activity2.py
python3 scripts/gen_class.py
python3 scripts/gen_state.py
```

Les images sont écrites dans `diagrams/`.
